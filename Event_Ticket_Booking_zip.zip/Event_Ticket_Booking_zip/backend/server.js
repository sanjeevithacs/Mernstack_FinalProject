const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const QRCode = require('qrcode');
const app = express();
app.use(express.json());
app.use(cors());

const bookingSchema = new mongoose.Schema({
  userName: String,
  numTickets: Number,
  eventName: String,
});

const userSchema = new mongoose.Schema({
  userName: String,
  numTickets: Number,
  eventName: String,
});

const paymentSchema = new mongoose.Schema({
  bookingIds: [String],
  userName: String,
  userEmail: String,
  seatingMode: String,
  eventType: String,
  amount: Number,
});

const Booking = mongoose.model('Booking', bookingSchema);
const User = mongoose.model('User', userSchema);
const Payment = mongoose.model('Payment', paymentSchema);

mongoose.connect('mongodb://localhost:27017/events')
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('MongoDB connection error:', error));

app.post('/api/bookings/book', async (req, res) => {
  try {
    const { eventId, userName, userEmail, seats, seatingMode, paymentMethod, eventType } = req.body;

    const newBooking = new Booking({
      eventId,
      userName,
      userEmail,
      seats,
      seatingMode,
      paymentMethod,
      eventType,
    });
    const savedBooking = await newBooking.save();

    const bookingIds = [savedBooking._id];

    res.status(200).json({ bookingIds });
  } catch (error) {
    console.error('Error booking event:', error);
    res.status(500).json({ message: 'Error booking event' });
  }
});



app.post('/api/payments/save', async (req, res) => {
  try {
    const { bookingIds, userName, userEmail, seatingMode, eventType, amount } = req.body;

    const newPayment = new Payment({
      bookingIds,
      userName,
      userEmail,
      seatingMode,
      eventType,
      amount,
    });
    await newPayment.save();

    res.status(200).json({ message: 'Payment Successful' });
  } catch (error) {
    console.error('Error saving payment:', error);
    res.status(500).json({ message: 'Error processing payment' });
  }
});

app.post('/api/users/saveUserData', async (req, res) => {
  const { userName, numTickets, eventName } = req.body;

  try {
    const newUser = new User({
      userName,
      numTickets,
      eventName,
    });
    await newUser.save();
    res.status(200).send({ message: 'User data saved successfully' });
  } catch (error) {
    console.error('Error saving user data:', error);
    res.status(500).send({ message: 'Error saving user data' });
  }
});

app.listen(1416, () => {
  console.log('Server running on port 1416');
});
