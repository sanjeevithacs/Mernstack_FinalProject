import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';  // Import useNavigate
import { fetchEvents } from '../services/api';
import '../styles/EventPage.css';

const EventPage = () => {
  const { state } = useLocation();
  const { eventType, language } = state || {};
  const [events, setEvents] = useState([]);
  const navigate = useNavigate();  // Hook for navigation

  useEffect(() => {
    const getEvents = async () => {
      if (eventType && language) {
        const fetchedEvents = await fetchEvents(eventType, language);
        setEvents(fetchedEvents);
      }
    };
    getEvents();
  }, [eventType, language]);

  const handleBookNow = (event) => {
    navigate('/booking', { state: { selectedEvent: event } });  
  };

  return (
    <div className="event-container">
      <h2>Available Events</h2>
      {events.length > 0 ? (
        <ul>
          {events.map((event) => (
            <li key={event._id}>
              <h3>{event.title}</h3>
              <p>{event.description}</p>
              <p><strong>Date:</strong> {event.date}</p>
              <p><strong>Location:</strong> {event.location}</p>
              <p><strong>Timing:</strong> {event.timing}</p>
              <p><strong>Seat Type:</strong> {event.seatType}</p>
              <p><strong>Alumni Speaker:</strong> {event.alumniDetails || 'Not Available'}</p>
              <p><strong>Contact:</strong> {event.contactDetails}</p>
              <button onClick={() => handleBookNow(event)}>Book Now</button>  
            </li>
          ))}
        </ul>
      ) : (
        <p>No events found for the selected criteria.</p>
      )}
    </div>
  );
};

export default EventPage;
