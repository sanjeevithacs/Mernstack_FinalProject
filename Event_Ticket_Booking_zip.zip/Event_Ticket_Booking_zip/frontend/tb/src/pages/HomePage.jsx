import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/HomePage.css';
const HomePage = () => {
  const [eventType, setEventType] = useState('');
  const [language, setLanguage] = useState('');
  const navigate = useNavigate();

  const handleFilterChange = () => {
    if (eventType && language) {
      navigate('/events', { state: { eventType, language } });
    } else {
      alert('Please select both event type and language.');
    }
  };

  return (
    <div className="home-container">
      <h2>Welcome to Event Booking</h2>
      <p>Choose your event type and language to see available events.</p>
      <div className="filter-container">
        <select onChange={(e) => setEventType(e.target.value)} value={eventType}>
          <option value="">Select Event Type</option>
          <option value="entertainment">Entertainment</option>
          <option value="seminar">Seminar</option>
          <option value="cultural">Cultural</option>
          <option value="concert">Concert</option>
        </select>
        <select onChange={(e) => setLanguage(e.target.value)} value={language}>
          <option value="">Select Language</option>
          <option value="english">English</option>
          <option value="tamil">Tamil</option>
        </select>
        <button onClick={handleFilterChange}>View Events</button>
      </div>
    </div>
  );
};

export default HomePage;
