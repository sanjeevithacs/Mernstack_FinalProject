import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const BookingPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const selectedEvent = location.state?.selectedEvent;

  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [numTickets, setNumTickets] = useState(1);
  const [seatingMode, setSeatingMode] = useState('silver');
  const [totalPrice, setTotalPrice] = useState(100);

  // Seating mode prices
  const seatingPrices = {
    silver: 100,
    gold: 200,
    platinum: 300,
  };

  // Calculate the total price based on tickets and seating mode
  useEffect(() => {
    setTotalPrice(seatingPrices[seatingMode] * numTickets);
  }, [numTickets, seatingMode]);

  // Handle the form submission and navigate to the payment page
  const handleSubmit = () => {
    if (!userName || !userEmail || !/\S+@\S+\.\S+/.test(userEmail)) {
      alert('Please enter a valid name and email.');
      return;
    }

    if (!selectedEvent) {
      alert('No event selected.');
      return;
    }

    navigate('/payment', {
      state: {
        selectedEvent,
        userName,
        userEmail,
        numTickets,
        seatingMode,
        totalPrice,
      },
    });
  };

  return (
    <div>
      <h1>Book Your Tickets for {selectedEvent?.title}</h1>
      <form>
        <label>
          Your Name:
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Your Email:
          <input
            type="email"
            value={userEmail}
            onChange={(e) => setUserEmail(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Number of Tickets:
          <input
            type="number"
            value={numTickets}
            min="1"
            onChange={(e) => setNumTickets(Number(e.target.value))}
          />
        </label>
        <br />
        <label>
          Seating Mode:
          <select value={seatingMode} onChange={(e) => setSeatingMode(e.target.value)}>
            <option value="silver">Silver - ₹100</option>
            <option value="gold">Gold - ₹200</option>
            <option value="platinum">Platinum - ₹300</option>
          </select>
        </label>
        <br />
        <h3>Total Price: ₹{totalPrice}</h3>
        <button type="button" onClick={handleSubmit}>Submit</button>
      </form>
    </div>
  );
};

export default BookingPage;
