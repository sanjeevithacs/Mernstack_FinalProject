import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import '../styles/PaymentPage.css';
// Function to save booking to MongoDB


const PaymentPage = () => {
  const location = useLocation();
  const selectedEvent = location.state?.selectedEvent;
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [qrCode, setQrCode] = useState('');
  const [showQrCode, setShowQrCode] = useState(false);
  const [numTickets, setNumTickets] = useState(1);
  const [seatingMode, setSeatingMode] = useState('silver');
  const [totalPrice, setTotalPrice] = useState(100);
  const [bookingIds, setBookingIds] = useState([]);
  const [loading, setLoading] = useState(false);


  const saveBookingToDB = async () => {
    if (!selectedEvent) {
      alert('No event selected.');
      return;
    }
  
    setLoading(true); // Start loading
  
    try {
      const response = await axios.post('http://localhost:1416/api/bookings/book', {
        userName: location.state?.userName || 'Guest', 
        numTickets:location.state?.numTickets,
        eventName: selectedEvent.title,
      });
  
      if (response.status === 200) {
        alert('Booking saved successfully!');
      }
    } catch (error) {
      console.error('Error saving booking:', error);
      alert('Failed to save booking. Please try again.');
    } finally {
      setLoading(false); // Stop loading
    }
  };
  // Seating mode prices
  const seatingPrices = {
    silver: 100,
    gold: 200,
    platinum: 300,
  };

  // Update total price dynamically
  useEffect(() => {
    setTotalPrice(seatingPrices[seatingMode] * numTickets);
  }, [numTickets, seatingMode]);

  // Function to handle the booking and generate QR code
  const generateQRCode = async () => {
    if (!selectedEvent) {
      alert('No event selected.');
      return;
    }

    setLoading(true); // Start loading

    try {
      const response = await axios.post('http://localhost:1416/api/bookings/book', {
        eventId: selectedEvent._id,
        seats: location.state?.numTickets,
        seatingMode,
        paymentMethod: 'UPI',
        eventType: selectedEvent.title,
      });

      if (response.status === 200) {
        const generatedIds = response.data.bookingIds;
        setBookingIds(generatedIds);
        const qrData = `Event: ${selectedEvent.title}\nSeating: ${seatingMode.toUpperCase()}\nTickets: ${numTickets}\nTotal: ₹${totalPrice}\nBooking IDs: ${generatedIds.join(', ')}`;
        const qrCodeUrl = await QRCode.toDataURL(qrData);
        setQrCode(qrCodeUrl);
        setShowQrCode(true);
      }
    } catch (error) {
      console.error('Error saving booking:', error);
      alert('Failed to process booking. Please try again.');
    } finally {
      setLoading(false); // Stop loading
    }
  };




  // Handle payment confirmation
  const handlePaymentSuccess = async () => {
    setLoading(true); // Start loading

    try {
      const response = await axios.post('http://localhost:1416/api/payments/save', {
        bookingIds,
        seatingMode:location.state?.seatingMode,
        eventType: selectedEvent.title,
        amount: location.state?.totalPrice || totalPrice,
      });
      console.log(response)

      if (response.status === 200) {
        setPaymentStatus('Payment Successful! Booking Confirmed.');
      }
    } catch (error) {
      console.error('Error saving payment data:', error);
      setPaymentStatus('Error confirming payment. Please try again.');
    } finally {
      setLoading(false); // Stop loading
    }
  };

  // Exit button functionality to save data in MongoDB
  const handleExit = async () => {
    try {
        const response = await axios.post('http://localhost:1416/api/users/saveUserData', {
        userName: location.state?.userName || 'Guest', 
        numTickets:location.state?.numTickets,
        eventName: selectedEvent.title,
      });

      if (response.status === 200) {
        alert('Data saved successfully. You can now exit.');
      }
    } catch (error) {
      console.error('Error saving user data:', error);
      alert('Error saving data. Please try again.');
    }
  };

  if (!selectedEvent) {
    return <p>No event selected for payment.</p>;
  }

  return (
    <div className="payment-page">
      <h1>{selectedEvent.title}</h1>

      <p><strong>Date:</strong> {selectedEvent.date}</p>
      <p><strong>Location:</strong> {selectedEvent.location}</p>
      <p><strong>Timing:</strong> {selectedEvent.timing}</p>

      <button onClick={generateQRCode} disabled={loading}>
        {loading ? 'Processing...' : 'Pay'}
      </button>

      {showQrCode && (
        <div>
          <img
            src={qrCode}
            alt="QR Code for payment"
            
            style={{ cursor: 'pointer' }}
          />
          <p>Scan the QR code to complete the payment.</p>
        </div>
      )}

      {paymentStatus && <h3>{paymentStatus}</h3>}
      <button onClick={handlePaymentSuccess}>save payment</button>
      <button onClick={saveBookingToDB} disabled={loading}>
  {loading ? 'Saving...' : 'Save Booking'}
</button>

      <button onClick={handleExit}>Exit</button>
    </div>
  );
};

export default PaymentPage;
