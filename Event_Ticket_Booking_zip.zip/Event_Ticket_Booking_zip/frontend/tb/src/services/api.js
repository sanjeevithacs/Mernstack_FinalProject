// src/services/api.js
import axios from 'axios';

const API_URL = 'https://api.example.com'; // Change to your actual API endpoint

const api = axios.create({
  baseURL: API_URL,
});

export const fetchEvents = async (eventType, language) => {
    try {
      const response = await fetch('/events.json');
      const data = await response.json();
  
      // Filter events based on type and language
      return data.filter(
        (event) => event.showType.toLowerCase() === eventType.toLowerCase() && event.language.toLowerCase() === language.toLowerCase()
      );
    } catch (error) {
      console.error('Error fetching events:', error);
      return [];
    }
  };
  

export const bookTicket = async (eventId) => {
  try {
    const response = await api.post(`/book/${eventId}`);
    return response.data;
  } catch (error) {
    console.error('Error booking ticket:', error);
  }
};

export const processPayment = async (paymentDetails) => {
  try {
    const response = await api.post('/payment', paymentDetails);
    return response.data;
  } catch (error) {
    console.error('Error processing payment:', error);
  }
};
