import { Link } from 'react-router-dom';

function EventCard({ event }) {
  return (
    <div className="event-card">
      <h3>{event.name}</h3>
      <p>{event.date}</p>
      <Link to={`/event/${event._id}`}>View Details</Link>
    </div>
  );
}

export default EventCard;
