import React, { useState } from 'react';
import axios from 'axios';
import '../styles/BookingPage.css';

const BookingForm = ({ eventId, userId }) => {
    const [seats, setSeats] = useState(1);
    const [paymentMethod, setPaymentMethod] = useState("card");

    const handleBooking = async () => {
        try {
            const response = await axios.post('http://localhost:1000/api/bookings/book', {
                eventId,
                userId,
                seats,
                paymentMethod
            });

            alert("Booking Successful!");
        } catch (error) {
            console.error("Booking Failed", error);
            alert("Failed to book ticket!");
        }
    };

    return (
        <div className="booking-form">
            <h3>Book Tickets</h3>
            <label>Seats:</label>
            <input type="number" value={seats} min="1" onChange={(e) => setSeats(e.target.value)} />

            <label>Payment Method:</label>
            <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                <option value="card">Card</option>
                <option value="upi">UPI</option>
                <option value="netbanking">Net Banking</option>
            </select>

            <button onClick={handleBooking}>Book Now</button>
        </div>
    );
};

export default BookingForm;
