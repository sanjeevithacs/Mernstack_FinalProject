import React, { useState } from 'react';

const FilterBar = ({ onFilterChange }) => {
  const [eventType, setEventType] = useState('');
  const [language, setLanguage] = useState('');

  const handleFilterChange = () => {
    onFilterChange({ eventType, language });
  };

  return (
    <div>
      <label>Event Type:</label>
      <select value={eventType} onChange={(e) => setEventType(e.target.value)}>
        <option value="">All</option>
        <option value="concert">Concert</option>
        <option value="theater">Theater</option>
        <option value="sports">Sports</option>
      </select>
      
      <label>Language:</label>
      <select value={language} onChange={(e) => setLanguage(e.target.value)}>
        <option value="">All</option>
        <option value="english">English</option>
        <option value="spanish">Spanish</option>
        <option value="french">French</option>
      </select>
      
      <button onClick={handleFilterChange}>Apply Filters</button>
    </div>
  );
};

export default FilterBar;
